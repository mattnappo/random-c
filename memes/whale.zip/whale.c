int main() {
    printf("                   __   __  \n");
    printf("              __ \\ / __     \n");
    printf("             /  \\ | /  \\    \n");
    printf("                 \\|/        \n");
    printf("            _,.---v---._    \n");
    printf("   /\\__/\\  /            \\   \n");
    printf("   \\_  _/ /              \\  \n");
    printf("     \\ \\_|           @ __|  \n");
    printf("  hjw \\                \\_   \n");
    printf("  `97  \\     ,__/       /   \n");
    printf("     ~~~`~~~~~~~~~~~~~~/~~~~\n");
}